import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

# Streamlit App Title
st.title("Loan Repayment Prediction App")

# File Uploader
uploaded_file = st.file_uploader("Upload CSV File", type=["csv"])

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    st.write("Dataset Preview:")
    st.write(df.head())

    # Select relevant columns
    features = ['Loan', 'Balance', 'Paid', 'Savings', 'Interest', 'TermInWeeks']
    df = df[features]
    df = df.dropna()

    # Create target variable based on Balance
    df['RepaymentSuccess'] = (df['Balance'] > 0.5 * df['Loan']).astype(int)

    # Data Visualization
    st.subheader("Data Visualization")
    fig, ax = plt.subplots()
    sns.scatterplot(data=df, x='Loan', y='Paid', hue='RepaymentSuccess', ax=ax)
    st.pyplot(fig)

    fig, ax = plt.subplots()
    sns.barplot(data=df, x='TermInWeeks', y='Paid', hue='RepaymentSuccess', ax=ax)
    st.pyplot(fig)

    # Model Training
    X = df[features]
    y = df['RepaymentSuccess']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    model.fit(X_train, y_train)

    # User Input for Prediction
    st.subheader("Predict Loan Repayment")
    user_input = {}
    for feature in features:
        user_input[feature] = st.number_input(f"Enter {feature}", value=0.0)
    
    if st.button("Predict"):
        input_df = pd.DataFrame([user_input])
        prediction = 1 if input_df['Balance'][0] > 0.5 * input_df['Loan'][0] else 0
        result = "Loan will be repaid" if prediction == 1 else "Loan may not be repaid"
        st.write(f"Prediction: {result}")
