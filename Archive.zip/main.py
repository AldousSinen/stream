import streamlit as st

st.title("THIS IS THE GREATEST SHOW")
st.subheader("It is always fun to be here!")
st.write("Join us and earn great salary!")
st.divider()
st.image("371461879_795595179066361_7370022226711550654_n.jpg", width=500, caption="this is roldan")



